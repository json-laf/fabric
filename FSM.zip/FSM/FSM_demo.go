package main

import (
	"fmt"
	. "studygo/FSM/src"
)

var (
	//
	PowerOff   = FSMState("关闭")
	FirstGear  = FSMState("1档")
	SecondGear = FSMState("2档")
	ThirdGear  = FSMState("3档")
	//
	PowerOffEvent   = FSMEvent("按下关闭按钮")
	FirstGearEvent  = FSMEvent("按下1档按钮")
	SecondGearEvent = FSMEvent("按下2档按钮")
	ThirdGearEvent  = FSMEvent("按下3档按钮")
	//
	PowerOffHandler = FSMHandler(func() FSMState {
		fmt.Println("电风扇已关闭")
		return PowerOff
	})
	FirstGearHandler = FSMHandler(func() FSMState {
		fmt.Println("电风扇开启1档！")
		return FirstGear
	})
	SecondGearHandler = FSMHandler(func() FSMState {
		fmt.Println("电风扇开启2档！")
		return SecondGear
	})
	ThirdGearHandler = FSMHandler(func() FSMState {
		fmt.Println("电风扇开启3档！")
		return ThirdGear
	})
)

//电风扇
type ElectricFan struct {
	*FSM
}

//实例化电风扇
func NewElectricFan(initState FSMState) *ElectricFan {
	return &ElectricFan{
		FSM: NewFSM(initState),
	}
}

//入口函数
func main() {
	//电风扇实例
	efan := NewElectricFan(PowerOff)

	//关闭状态
	efan.AddHandler(PowerOff, PowerOffEvent, PowerOffHandler)
	efan.AddHandler(PowerOff, FirstGearEvent, FirstGearHandler)
	efan.AddHandler(PowerOff, SecondGearEvent, SecondGearHandler)
	efan.AddHandler(PowerOff, ThirdGearEvent, ThirdGearHandler)
	//1档状态
	efan.AddHandler(FirstGear, PowerOffEvent, PowerOffHandler)
	efan.AddHandler(FirstGear, FirstGearEvent, FirstGearHandler)
	efan.AddHandler(FirstGear, SecondGearEvent, SecondGearHandler)
	efan.AddHandler(FirstGear, ThirdGearEvent, ThirdGearHandler)
	//2档状态
	efan.AddHandler(SecondGear, PowerOffEvent, PowerOffHandler)
	efan.AddHandler(SecondGear, FirstGearEvent, FirstGearHandler)
	efan.AddHandler(SecondGear, SecondGearEvent, SecondGearHandler)
	efan.AddHandler(SecondGear, ThirdGearEvent, ThirdGearHandler)
	//3档状态
	efan.AddHandler(ThirdGear, PowerOffEvent, PowerOffHandler)
	efan.AddHandler(ThirdGear, FirstGearEvent, FirstGearHandler)
	efan.AddHandler(ThirdGear, SecondGearEvent, SecondGearHandler)
	efan.AddHandler(ThirdGear, ThirdGearEvent, ThirdGearHandler)

	//开始测试状态变化
	efan.Call(ThirdGearEvent)
	efan.Call(FirstGearEvent)
	efan.Call(PowerOffEvent)
	efan.Call(SecondGearEvent)
	efan.Call(PowerOffEvent)
	efan.Call(ThirdGearEvent)
}
