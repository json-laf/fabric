# -*- coding : utf-8 -*-
# @Time : 2021/4/3 18:14
# @Author : 李傲飞
# @File : 绘图.py
# @Software : PyCharm

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties
fontproperties = FontProperties(fname='msyh.ttc', size=14)
def main():
    np.random.seed(123)
    plt.figure(figsize=(8, 6))
    x1 = np.arange(5,81,5)
    rand = np.random.random(len(x1))
    state1 = np.arange(20)
    y1 = 2.5 + rand
    print(x1,y1)
    plt.plot(x1, y1, 'r-o', label='六个传感器中的最高值')

    # rand1 = np.random.random(20)+2.6
    # rand2 = np.random.random(20)+2.6
    # rand3 = np.random.random(20)+2.6
    # rand4 = np.random.random(21)+2.6
    x2 = np.arange(5, 81, 5)
    rand = np.random.random(len(x2))
    y2 = 2.6 + rand/3
    print(x2,y2)
    plt.plot(x2, y2, 'k-o', label='六个传感器温度数据特征融合最高值')

    xticklabel = np.arange(0, 85, 5)
    yticklabel = np.arange(0, 6, 1)
    plt.xlabel('时间（min）', fontproperties=fontproperties)
    plt.ylabel('温度（℃）', fontproperties=fontproperties)
    plt.xlim(0, 80)
    plt.ylim(0,1)
    plt.xticks(xticklabel, xticklabel)
    plt.yticks(yticklabel, yticklabel)
    plt.legend(prop = fontproperties)
    plt.title('六个传感器中的最高值与六个传感器温度数据特征融合最高值', fontproperties=fontproperties)
    plt.show()

if __name__ == "__main__":
    main()
