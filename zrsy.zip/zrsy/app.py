from flask import Flask,render_template,request
import sqlite3,json

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/frame',methods = ['POST','GET'])
def frame():
    if request.method == 'POST':
        info = request.form.to_dict()
        # print(info)
        ls = []
        list = []
        con = sqlite3.connect('demo.db')
        cur = con.cursor()
        sql = 'select * from user_info'
        try:
            data = cur.execute(sql)  # Cursor object
        except Exception as e:
            con.rollback()
            print(e)
        finally:
            for item in data:
                ls.append(item[2])#ls = ['13999999999', '13888888888']
                list.append(item[3])
            for i in ls:
                for j in list:
                    if i == info['用户名'] and j == info['登录密码']:
                        cur.close()
                        con.close()
                        return render_template('frame.html')
            cur.close()
            con.close()
            return '您的输入有误！'
    else:
        return render_template('frame.html')

@app.route('/logistics')
def logistics():
    return render_template('logistics.html')

@app.route('/receive',methods = ['POST','GET'])
def receive():
    # web3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))
    register_1 = request.form
    company = register_1['物流企业']
    time = register_1['配送时间']
    car = register_1['配送车辆']
    employee = register_1['配送人员']
    temperature = register_1['温度检测']
    route = register_1['物流运输路线信息']
    tuple = (company,time,car,employee,temperature,route)
    con = sqlite3.connect(r'C:\Users\19076\Desktop\zrsy\demo.db')  # 连接数据库
    cur = con.cursor()  # 创建游标
    sql = '''insert into logistics(company,time,car,employee,temperature,route) values(?,?,?,?,?,?)'''
    try:
        cur.execute(sql, tuple)
        con.commit()
        # if web3.isConnected():
        #     abi = json.loads('[{"constant":true,"inputs":[{"name":"operateID","type":"uint256"}],"name":"getOperationData","outputs":[{"name":"_operateID","type":"uint256"},{"name":"_operatorName","type":"string"},{"name":"_machineID","type":"uint256"},{"name":"_classification","type":"uint256"},{"name":"_weight","type":"uint256"},{"name":"_volume","type":"uint256"},{"name":"_value","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"operateID","type":"uint256"},{"name":"operatorName","type":"string"},{"name":"machineID","type":"uint256"},{"name":"classification","type":"uint256"},{"name":"weight","type":"uint256"},{"name":"volume","type":"uint256"},{"name":"value","type":"uint256"}],"name":"addNewOperationData","outputs":[{"name":"stateNum","type":"uint256"},{"name":"message","type":"string"},{"name":"O_value","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"function"},{"inputs":[{"name":"c_limit","type":"uint256"},{"name":"w_limit","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_operatorID","type":"uint256"},{"indexed":false,"name":"errorNum","type":"uint256"},{"indexed":false,"name":"errorMessage","type":"string"}],"name":"DataErrorWarning","type":"event"}]')
        #     contractAddress = '0xDafC67A932F9D042488ff324F38A0f74b729a932'
        #     smart_contract.callContract_add(web3, abi, contractAddress, int(company), str('a'),int(time), int(car), int(employee), int(temperature), int(route))
        print('插入数据成功')
    except Exception as e:
        print(e)
        con.rollback()
        print('插入失败')
    finally:
        cur.close()
        con.close()
    return render_template('logistics.html')

if __name__ == '__main__':
    app.run()
