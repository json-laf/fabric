# -*- coding : utf-8 -*-
# @Time : 2020/10/8 16:46
# @Author : 李傲飞
# @File : smart_contract.py
# @Software : PyCharm

from web3 import Web3
import json

def deployContract(web3,abi): #部署合约
    classification = int(input('请输入最低分类级别:'))
    w_limit = int(input('请输入质量上限:'))
    bytecode = "6080604052600160025560026003556040516040806107a383398101806040528101908080519060200190929190805190602001909291905050508160008190555080600181905550505061074a806100596000396000f30060806040526004361061004c576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff16806306da6e6914610051578063fc6434a314610121575b600080fd5b34801561005d57600080fd5b5061007c60048036038101908080359060200190929190505050610240565b6040518088815260200180602001878152602001868152602001858152602001848152602001838152602001828103825288818151815260200191508051906020019080838360005b838110156100e05780820151818401526020810190506100c5565b50505050905090810190601f16801561010d5780820380516001836020036101000a031916815260200191505b509850505050505050505060405180910390f35b6101b760048036038101908080359060200190929190803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001909291908035906020019092919080359060200190929190803590602001909291908035906020019092919050505061039e565b6040518084815260200180602001838152602001828103825284818151815260200191508051906020019080838360005b838110156102035780820151818401526020810190506101e8565b50505050905090810190601f1680156102305780820380516001836020036101000a031916815260200191505b5094505050505060405180910390f35b60006060600080600080600060046000898152602001908152602001600020600001549650600460008981526020019081526020016000206001018054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561030f5780601f106102e45761010080835404028352916020019161030f565b820191906000526020600020905b8154815290600101906020018083116102f257829003601f168201915b505050505095506004600089815260200190815260200160002060020154945060046000898152602001908152602001600020600301549350600460008981526020019081526020016000206004015492506004600089815260200190815260200160002060050154915060046000898152602001908152602001600020600601549050919395979092949650565b6000606060006103ac61063b565b8a816000018181525050898160200181905250888160400181815250508781606001818152505086816080018181525050858160a0018181525050848160c001818152505080600460008d815260200190815260200160002060008201518160000155602082015181600101908051906020019061042b929190610679565b5060408201518160020155606082015181600301556080820151816004015560a0820151816005015560c08201518160060155905050600054881015801561047557506001548711155b156104bb57600093506040805190810160405280601e81526020017f746865206e657720646174612061646473207375636365737366756c6c7900008152509250610624565b600193506040805190810160405280601e81526020017f546865726520697320616e2064617461207761726e696e67206f63637572000081525092506000548811151561058d578a3373ffffffffffffffffffffffffffffffffffffffff167f5e3d3744697dfe14ef4ca2711f41f8b545c4d38b2b9381e5825a805e84a1dd5960025460405180828152602001806020018281038252601a8152602001807f74686520636c617373696669636174696f6e20746f6f206c6f770000000000008152506020019250505060405180910390a35b60015487101515610623578a3373ffffffffffffffffffffffffffffffffffffffff167f5e3d3744697dfe14ef4ca2711f41f8b545c4d38b2b9381e5825a805e84a1dd596003546040518082815260200180602001828103825260138152602001807f7468652077656967687420746f6f2068696768000000000000000000000000008152506020019250505060405180910390a35b5b838386935093509350509750975097945050505050565b60e060405190810160405280600081526020016060815260200160008152602001600081526020016000815260200160008152602001600081525090565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106106ba57805160ff19168380011785556106e8565b828001600101855582156106e8579182015b828111156106e75782518255916020019190600101906106cc565b5b5090506106f591906106f9565b5090565b61071b91905b808211156107175760008160009055506001016106ff565b5090565b905600a165627a7a723058200e6dc4aa8fd337179c093303489f3b1f3916d6d92f4b853478db8c2d3dbe33e10029"
    GarbageClassification = web3.eth.contract(abi=abi, bytecode=bytecode)
    tx_hash = GarbageClassification.constructor(classification, w_limit).transact()  # 将合约部署到区块链上.返回该交易的哈希值
    tx_receipt = web3.eth.waitForTransactionReceipt(tx_hash)  # 返回交易的详细信息
    print('合约部署成功！该合约的地址为：{}'.format(tx_receipt.contractAddress))
    return tx_receipt.contractAddress

def callContract_add(web3,abi,contractAddress,operateID,operatorName,machineID,classification,weight,volume,value): #通过合约添加数据
    # operateID = int(input('请输入操作ID：'))
    # operatorName = input('请输入用户名：')
    # machineID = int(input('请输入机器ID：'))
    # classification = int(input('请输入分类等级：'))
    # weight = int(input('请输入质量：'))
    # volume = int(input('请输入体积：'))
    # value = int(input('请输入值：'))
    web3.eth.defaultAccount = web3.eth.accounts[0]
    address = web3.toChecksumAddress(contractAddress) #合约的地址
    contract = web3.eth.contract(address=address, abi=abi) #智能合约
    tx_hash = contract.functions.addNewOperationData(operateID, operatorName, machineID, classification, weight, volume, value).transact() #transact()调用需要写入区块链数据的函数，因为写入数据需要gas，返回交易的hash
    web3.eth.waitForTransactionReceipt(tx_hash) #等待交易被挖矿/确认
    info = contract.functions.getOperationData(operateID).call() #contract.functions调用智能合约中的函数，返回值为列表类型
    # print(info)

def callContract_get(web3,abi,contractAddress): #通过合约查询数据
    operateID = int(input('请输入需要查询的操作ID：'))
    address = web3.toChecksumAddress(contractAddress) #合约的地址
    contract = web3.eth.contract(address=address, abi=abi) #智能合约
    info = contract.functions.getOperationData(operateID).call() #contract.functions调用智能合约中的函数，返回值为列表类型
    print(info)

def get(web3,from_account,to_account,account_privatekey): # 发起一笔交易
    val = int(input('请输入需要转账的eth数量：'))
    nonce = web3.eth.getTransactionCount(from_account) #获得nnce
    tx = {
        'nonce': nonce,
        'to': to_account,
        'value': web3.toWei(val, 'ether'), #交易的值
        'gas': 2000000, #gas的极限
        'gasPrice': web3.toWei('50', 'gwei'),
    } #创建一笔交易
    signed_tx = web3.eth.account.signTransaction(tx, account_privatekey) #使用私钥对交易进行签名，以告知account正在发送以太币
    tx_hash = web3.eth.sendRawTransaction(signed_tx.rawTransaction) #将交易发送到newtork
    # print(web3.toHex(tx_hash)) #将交易哈希值转换为十六进制

def getBlock(web3): #查询某一区块信息
    blockNum = int(input('请输入需要查询的区块号：'))
    block_hash = input('请输入查询区块的hash值：')
    latest = web3.eth.blockNumber #最新的区块号
    print(latest)
    print(web3.eth.getBlock(latest)) #查询区块的详细信息
    tx_info = web3.eth.getTransactionByBlock(block_hash,0) #查询区块的第一个交易的详细信息
    print(tx_info)

def getAccount(web3): #查询某一账户信息
    account = input('请输入需要查询的账号：')
    wei_balance = web3.eth.getBalance(account)  #查询账号余额，单位为wei；1 eth = 10^18 wei
    eth_balance = web3.fromWei(wei_balance, "ether")  # 将wei转化为eth
    print('该账号共有{}wei，{}eth'.format(wei_balance, eth_balance))

def main():
    web3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))  # 实例化web3连接，该可以与以太坊网络交互
    if web3.isConnected():#确认是否与以太坊连接，连接则返回True
        web3.eth.defaultAccount = web3.eth.accounts[0]  # 设置默认账号，不需要用私钥解锁
        abi = json.loads('[{"constant":true,"inputs":[{"name":"operateID","type":"uint256"}],"name":"getOperationData","outputs":[{"name":"_operateID","type":"uint256"},{"name":"_operatorName","type":"string"},{"name":"_machineID","type":"uint256"},{"name":"_classification","type":"uint256"},{"name":"_weight","type":"uint256"},{"name":"_volume","type":"uint256"},{"name":"_value","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"operateID","type":"uint256"},{"name":"operatorName","type":"string"},{"name":"machineID","type":"uint256"},{"name":"classification","type":"uint256"},{"name":"weight","type":"uint256"},{"name":"volume","type":"uint256"},{"name":"value","type":"uint256"}],"name":"addNewOperationData","outputs":[{"name":"stateNum","type":"uint256"},{"name":"message","type":"string"},{"name":"O_value","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"function"},{"inputs":[{"name":"c_limit","type":"uint256"},{"name":"w_limit","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_operatorID","type":"uint256"},{"indexed":false,"name":"errorNum","type":"uint256"},{"indexed":false,"name":"errorMessage","type":"string"}],"name":"DataErrorWarning","type":"event"}]')
        # contractAddress = deployContract(web3, abi) #部署合约，返回合约的地址
        contractAddress = '0xDafC67A932F9D042488ff324F38A0f74b729a932'
        # for i in range(0,3):
        # callContract_add(web3, abi, contractAddress) #向区块链写入数据
        # for i in range(0,3):
        # callContract_get(web3,abi,contractAddress)
        # to_account = web3.eth.accounts[1]
        # account_privatekey = '930152d3b448ba145dec295a812c48d1e83b09a1d569c9dc7da12492108af0e9'
        # get(web3, web3.eth.defaultAccount, to_account, account_privatekey)
        # getBlock(web3)
        # getAccount(web3)

if __name__ == "__main__":
    main()
    # print('1')