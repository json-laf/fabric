from flask import Flask,render_template,request
import sqlite3,smart_contract,json  # 引入sqlite3
from web3 import Web3 #引入Web3

app = Flask(__name__) # 实例化Flask，传递name

# user界面
@app.route('/')#登录
def index():
    return render_template('index.html')

@app.route('/login')#登录
def login():
    return render_template('login.html')

@app.route('/award')
def award():
    return render_template('award.html')

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/rank')
def rank():
    return render_template('rank.html')
@app.route('/search')
def search():
    return render_template('search.html')

@app.route('/register')#注册
def register():
    return render_template('register.html')

@app.route('/dashboard',methods=['POST','GET'])#注册
def dashboard():
    if request.method == 'POST':
        info = request.form.to_dict()
        ls = []
        list = []
        con = sqlite3.connect('demo.db')
        cur = con.cursor()
        sql = 'select * from user_info'
        try:
            data = cur.execute(sql)  # Cursor object
        except Exception as e:
            con.rollback()
        finally:
            for item in data:
                ls.append(item[2])  # ls = ['13999999999', '13888888888']
                list.append(item[3])
            print(ls)
            for i in ls:
                for j in list:
                    if i == info['用户名'] and j == info['登录密码'] and info['验证码'] == '8ts2':
                        cur.close()
                        con.close()
                        return render_template('dashboard.html')
            cur.close()
            con.close()
            return '您的输入有误！'

@app.route('/profile',methods=['POST','GET'])#个人主页
def profile():
    if request.method == 'POST':
        info = request.form.to_dict()
        ls = []
        list = []
        con = sqlite3.connect('demo.db')
        cur = con.cursor()
        sql = 'select * from user_info'
        try:
            data = cur.execute(sql)  # Cursor object
        except Exception as e:
            con.rollback()
            print(e)
        finally:
            for item in data:
                ls.append(item[2])#ls = ['13999999999', '13888888888']
                list.append(item[3])
            for i in ls:
                for j in list:
                    if i == info['用户名'] and j == info['登录密码'] and info['验证码'] == '8ts2':
                        cur.close()
                        con.close()
                        return render_template('profile.html',i = i)
            cur.close()
            con.close()
            return '您的输入有误！'
    else:
        i = '13999999999'
        return render_template('profile.html', i = i)

@app.route('/register_1',methods=['POST','GET'])#提交注册信息
def register_1():
    if request.method == 'POST':
        register_1 = request.form.to_dict() #将ImmutableMultiDict转换为字典
        tuple = (register_1['手机号'],register_1['用户名'],register_1['登录密码'])
        con = sqlite3.connect(r'C:\Users\19076\Desktop\flask_demo\demo.db')  # 连接数据库
        cur = con.cursor()  # 创建游标
        sql = '''insert into user_info(phone,user_name,password) values(?,?,?)'''
        try:
            cur.execute(sql,tuple)
            con.commit()
            print('插入数据成功')
        except Exception as e:
            print(e)
            con.rollback()
            print('插入失败')
        finally:
            cur.close()
            con.close()
        return render_template('register_1.html',register_1 = register_1)

@app.route('/resetpassword')#整形路径
def resetpassword():
    return render_template('resetpassword.html')

@app.route('/resetpassword_1')#整形路径
def resetpassword_1():
    return render_template('resetpassword_1.html')

@app.route('/resetpassword_2')#整形路径
def resetpassword_2():
    return render_template('resetpassword_2.html')

# admin界面
@app.route('/404')#整形路径
def _404():
    return render_template('404.html')

@app.route('/member_list',methods = ['POST','GET'])
def member_list():
    infolist = []
    con = sqlite3.connect('demo.db')
    cur = con.cursor()
    sql = 'select * from user_info'
    try:
        data = cur.execute(sql)  # Cursor object
        # print(data)
        for item in data:
            infolist.append(
                item)  # [(1, '张三', '13999999999', '123456', 0, 0, None), (2, '李四', '13888888888', '123456789', 0, 0, None)]
            # print(item)
    except Exception as e:
        con.rollback()
    finally:
        cur.close()
        con.close()
    return render_template('member-list.html',infolist=infolist)
@app.route('/member_add',methods = ['POST','GET'])
def member_add():
    return render_template('member-add.html')
@app.route('/change_password',methods = ['POST','GET'])
def change_password():
    return render_template('change-password.html')
@app.route('/member_show',methods = ['POST','GET'])
def member_show():
    return render_template('member-show.html')
@app.route('/contract',methods = ['POST','GET'])
def contract():
    return render_template('contract.html')
@app.route('/result',methods = ['POST','GET'])
def result():
    if request.method == 'POST':
        web3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))
        info_dict = request.form
        operatorName = info_dict['operatorName']
        machineID = info_dict['machineID']
        classification = info_dict['classification']
        weight = info_dict['weight']
        volume = info_dict['volume']
        value = info_dict['value']
        tuple = (operatorName, machineID, classification, weight, volume, value)
        operateID = 0
        con = sqlite3.connect('demo.db')  # 连接数据库
        cur = con.cursor()  # 创建游标
        sql1 = 'select operateID from operate_info order by operateID desc limit 1'
        sql2 = 'insert into operate_info(operatorName, machineID, classification, weight, volume, value) values(?,?,?,?,?,?)'
        try:
            data = cur.execute(sql1)  # Cursor object
            for item in data:
                operateID = item[0] + 1
                # print(operateID)
            cur.execute(sql2, tuple)
            con.commit()
            if web3.isConnected():
                abi = json.loads('[{"constant":true,"inputs":[{"name":"operateID","type":"uint256"}],"name":"getOperationData","outputs":[{"name":"_operateID","type":"uint256"},{"name":"_operatorName","type":"string"},{"name":"_machineID","type":"uint256"},{"name":"_classification","type":"uint256"},{"name":"_weight","type":"uint256"},{"name":"_volume","type":"uint256"},{"name":"_value","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"operateID","type":"uint256"},{"name":"operatorName","type":"string"},{"name":"machineID","type":"uint256"},{"name":"classification","type":"uint256"},{"name":"weight","type":"uint256"},{"name":"volume","type":"uint256"},{"name":"value","type":"uint256"}],"name":"addNewOperationData","outputs":[{"name":"stateNum","type":"uint256"},{"name":"message","type":"string"},{"name":"O_value","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"function"},{"inputs":[{"name":"c_limit","type":"uint256"},{"name":"w_limit","type":"uint256"}],"payable":true,"stateMutability":"payable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_operatorID","type":"uint256"},{"indexed":false,"name":"errorNum","type":"uint256"},{"indexed":false,"name":"errorMessage","type":"string"}],"name":"DataErrorWarning","type":"event"}]')
                contractAddress = '0xDafC67A932F9D042488ff324F38A0f74b729a932'
                smart_contract.callContract_add(web3, abi, contractAddress, int(operateID), str(operatorName),int(machineID), int(classification), int(weight), int(volume),int(value))
            print('写入数据成功！')
        except Exception as e:
            con.rollback()
            print('插入失败，原因如下：')
            print(e)
        finally:
            cur.close()
            con.close()
            return render_template('result.html',value = value,classification = classification)

@app.route('/member_del',methods = ['POST','GET'])
def member_del():
    return render_template('member-del.html')

@app.route('/member_record-browse',methods = ['POST','GET'])
def member_record_browse():
    return render_template('member-record-browse.html')

@app.route('/admin_role',methods = ['POST','GET'])
def admin_role():
    return render_template('admin-role.html')

@app.route('/admin_role_add',methods = ['POST','GET'])
def admin_role_add():
    return render_template('admin-role-add.html')

@app.route('/admin_permission',methods = ['POST','GET'])
def admin_permission():
    return render_template('admin-permission.html')

@app.route('/admin_list',methods = ['POST','GET'])
def admin_list():
    infolist = []
    con = sqlite3.connect('demo.db')
    cur = con.cursor()
    sql = 'select * from admin_info'
    try:
        data = cur.execute(sql)  # Cursor object
        # print(data)
        for item in data:
            infolist.append(item)  # [(1, '张三', '13999999999', '123456', 0, 0, None), (2, '李四', '13888888888', '123456789', 0, 0, None)]
            # print(item)
    except Exception as e:
        con.rollback()
    finally:
        cur.close()
        con.close()
    return render_template('admin-list.html', infolist=infolist)
@app.route('/admin_add',methods = ['POST','GET'])
def admin_add():
    return render_template('admin-add.html')

@app.route('/charts_1',methods = ['POST','GET'])
def charts_1():
    return render_template('charts-1.html')

@app.route('/charts_2',methods = ['POST','GET'])
def charts_2():
    return render_template('charts-2.html')

@app.route('/charts_3',methods = ['POST','GET'])
def charts_3():
    return render_template('charts-3.html')

@app.route('/charts_4',methods = ['POST','GET'])
def charts_4():
    return render_template('charts-4.html')

@app.route('/charts_5',methods = ['POST','GET'])
def charts_5():
    return render_template('charts-5.html')

@app.route('/charts_6',methods = ['POST','GET'])
def charts_6():
    return render_template('charts-6.html')

@app.route('/charts_7',methods = ['POST','GET'])
def charts_7():
    return render_template('charts-7.html')

@app.route('/system_base',methods = ['POST','GET'])
def system_base():
    return render_template('system-base.html')

@app.route('/system_category',methods = ['POST','GET'])
def system_category():
    return render_template('system-category.html')
@app.route('/system_category_add',methods = ['POST','GET'])
def system_category_add():
    return render_template('system-category-add.html')

@app.route('/system_data',methods = ['POST','GET'])
def system_data():
    return render_template('system-data.html')

@app.route('/system_shielding',methods = ['POST','GET'])
def system_shielding():
    return render_template('system-shielding.html')

@app.route('/system_log',methods = ['POST','GET'])
def system_log():
    return render_template('system-log.html')

@app.route('/admin_login',methods = ['POST','GET'])
def admin_login():
    return render_template('admin-login.html')

@app.route('/admin_index',methods = ['POST','GET'])
def admin_index():
    if request.method == 'POST':
        info = request.form.to_dict()
        ls = []
        list = []
        con = sqlite3.connect('demo.db')
        cur = con.cursor()
        sql = 'select * from admin'
        try:
            data = cur.execute(sql)  # Cursor object
        except Exception as e:
            con.rollback()
            print(e)
        finally:
            for item in data:
                ls.append(item[1])#ls = ['13999999999', '13888888888']
                list.append(item[3])
            for i in ls:
                for j in list:
                    if i == info['用户名'] and j == info['登录密码'] and info['验证码'] == '8ts2':
                        cur.close()
                        con.close()
                        return render_template('admin-index.html')
            cur.close()
            con.close()
            return '您的输入有误！'
    else:
        i = '13999999999'
        return render_template('admin-index.html', i = i)

@app.route('/article_list',methods = ['POST','GET'])
def article_list():
    return render_template('article-list.html')
@app.route('/article_add',methods = ['POST','GET'])
def article_add():
    return render_template('article-add.html')

@app.route('/community_list',methods = ['POST','GET'])
def community_list():
    return render_template('community-list.html')
@app.route('/community_add',methods = ['POST','GET'])
def community_add():
    return render_template('community-add.html')
@app.route('/community_show',methods = ['POST','GET'])
def community_show():
    return render_template('community-show.html')

@app.route('/product_brand',methods = ['POST','GET'])
def product_brand():
    return render_template('product-brand.html')
@app.route('/codeing',methods = ['POST','GET'])
def codeing():
    return render_template('codeing.html')

@app.route('/product_category',methods = ['POST','GET'])
def product_category():
    return render_template('product-category.html')
@app.route('/product_category_add',methods = ['POST','GET'])
def product_category_add():
    return render_template('product-category-add.html')

@app.route('/product_list',methods = ['POST','GET'])
def product_list():
    return render_template('product-list.html')
@app.route('/product_add',methods = ['POST','GET'])
def product_add():
    return render_template('product-add.html')

@app.route('/feedback_list',methods = ['POST','GET'])
def feedback_list():
    return render_template('feedback-list.html')

if __name__ == '__main__':
    app.run(debug=True)
