from flask import Flask, render_template, request
import pysdk

app = Flask(__name__)

@app.route('/')
def frame():
    return render_template('frame.html')

#channel操作
@app.route('/channel_create')
def channel_create():
    return render_template('channel_create.html')
@app.route('/channel_create_result',methods = ['POST','GET'])
def channel_create_result():
    info = request.form
    channel_name = info['channel_name']
    response = pysdk.channel_create(channel_name)
    return response

@app.route('/channel_join')
def channel_join():
    return render_template('channel_join.html')
@app.route('/channel_join_result',methods = ['POST','GET'])
def channel_join_result():
    return '加入成功'

@app.route('/channel_update')
def channel_update():
    return render_template('channel_update.html')
@app.route('/channel_update_result',methods = ['POST','GET'])
def channel_update_result():
    return '更新成功'



#chaincode操作
@app.route('/chaincode_install')
def chaincode_install():
    return render_template('chaincode_install.html')
@app.route('/chaincode_install_result',methods = ['POST','GET'])
def chaincode_install_result():
    response = pysdk.chaincode_install()
    return response

@app.route('/chaincode_instantiate')
def chaincode_instantiate():
    return render_template('chaincode_instantiate.html')
@app.route('/chaincode_instantiate_result',methods = ['POST','GET'])
def chaincode_instantiate_result():
    response = pysdk.chaincode_instantiate()
    return response

@app.route('/chaincode_invoke')
def chaincode_invoke():
    return render_template('chaincode_invoke.html')
@app.route('/chaincode_invoke_result',methods = ['POST','GET'])
def chaincode_invoke_result():
    info = request.form
    ls = []
    ls.append(info['id'])
    response = pysdk.chaincode_invoke(ls)
    return response

@app.route('/chaincode_query')
def chaincode_query():
    return render_template('chaincode_query.html')
@app.route('/chaincode_query_result',methods = ['POST','GET'])
def chaincode_query_result():
    info = request.form
    ls = []
    ls.append(info['id'])
    response = pysdk.chaincode_query(ls)
    return response

@app.route('/chaincode_upgrade')
def chaincode_upgrade():
    return render_template('chaincode_upgrade.html')
@app.route('/chaincode_upgrade_result',methods = ['POST','GET'])
def chaincode_upgrade_result():
    return 'result'



#query操作
@app.route('/query_installed_chaincodes')
def query_installed_chaincodes():
    return render_template('query_installed_chaincodes.html')
@app.route('/query_installed_chaincodes_result',methods = ['POST','GET'])
def query_installed_chaincodes_result():
    return 'result'

@app.route('/query_channels')
def query_channels():
    return render_template('query_channels.html')
@app.route('/query_channels_result',methods = ['POST','GET'])
def query_channels_result():
    return 'result'

@app.route('/query_info')
def query_info():
    return render_template('query_info.html')
@app.route('/query_info_result',methods = ['POST','GET'])
def query_info_result():
    return 'result'

@app.route('/query_block_by_hash')
def query_block_by_hash():
    return render_template('query_block_by_hash.html')
@app.route('/query_block_by_hash_result',methods = ['POST','GET'])
def query_block_by_hash_result():
    return 'result'

@app.route('/query_block_by_txid')
def query_block_by_txid():
    return render_template('query_block_by_txid.html')
@app.route('/query_block_by_txid_result',methods = ['POST','GET'])
def query_block_by_txid_result():
    return 'result'

@app.route('/query_block')
def query_block():
    return render_template('query_block.html')
@app.route('/query_block_result',methods = ['POST','GET'])
def query_block_result():
    return 'result'

@app.route('/query_transaction')
def query_transaction():
    return render_template('query_transaction.html')
@app.route('/query_transaction_result',methods = ['POST','GET'])
def query_transaction_result():
    return 'result'

@app.route('/query_instantiated_chaincodes')
def query_instantiated_chaincodes():
    return render_template('query_instantiated_chaincodes.html')
@app.route('/query_instantiated_chaincodes_result',methods = ['POST','GET'])
def query_instantiated_chaincodes_result():
    return 'result'

@app.route('/get_channel_config')
def get_channel_config():
    return render_template('get_channel_config.html')
@app.route('/get_channel_config_result',methods = ['POST','GET'])
def get_channel_config_result():
    return 'result'

@app.route('/query_peers')
def query_peers():
    return render_template('query_peers.html')
@app.route('/query_peers_result',methods = ['POST','GET'])
def query_peers_result():
    return 'result'


if __name__ == '__main__':
    app.run()
