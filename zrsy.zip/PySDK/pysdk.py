# -*- coding : utf-8 -*-
# @Time : 2021/4/12 15:01
# @Author : 李傲飞
# @File : pysdk.py
# @Software : PyCharm
from hfc.fabric import Client
import asyncio, os

loop = asyncio.get_event_loop()
cli = Client(net_profile="py-sdk/network.json")  # 加载连接网络的文件
# SDK需要凭据文件成为有效的网络用户,通常有两种方法:使用cryptogen或使用Fabric-CA。
orderer_admin = cli.get_user(org_name='orderer.example.com', name='Admin')
org1_admin = cli.get_user(org_name='org1.example.com', name='Admin')
org2_admin = cli.get_user(org_name='org2.example.com', name='Admin')
mychannel = cli.new_channel('mychannel')  # 告知客户端当前加入的链码id


def channel_create(channel_name):  # 创建通道
    response = loop.run_until_complete(cli.channel_create(  # 创建一个新通道，如果成功返回为true
        orderer='orderer.example.com',
        channel_name=channel_name,
        requestor=org1_admin,
        config_yaml='test/fixtures/e2e_cli/',
        channel_profile='TwoOrgsChannel'
    ))
    if response == True:
        return '成功创建通道'
    else:
        return '创建通道失败'


def channel_join():  # 加入通道
    responses = loop.run_until_complete(cli.channel_join(  # 将Peer加入通道，如果成功则返回为true
        requestor=org2_admin,  # 对于来自org2.example.com的Peer操作，要求org2_admin作为请求者
        channel_name='mychannel',
        peers=['peer0.org2.example.com',
               'peer1.org2.example.com'],
        orderer='orderer.example.com'
    ))
    if len(responses) == 2:
        return '两个Peer加入通道mychennel1'
    else:
        return '加入通道失败'


def channel_update():  # 更新通道
    config_tx_file = './configtx.yaml'
    loop.run_until_complete(cli.channel_update(  # 更新通道配置
        orderer='orderer.example.com',
        channel_name='mychannel',
        requestor=orderer_admin,
        config_tx=config_tx_file))


def chaincode_install():  # 在Peer上安装指定Chaincode
    gopath_bak = os.environ.get('GOPATH', '')  # GOPATH setting is only needed to use the example chaincode inside sdk
    gopath = os.path.normpath(os.path.join(
        os.path.dirname(os.path.realpath('__file__')),
        'test/fixtures/chaincode'
    ))
    os.environ['GOPATH'] = os.path.abspath(gopath)
    responses = loop.run_until_complete(cli.chaincode_install(  # 安装链码，如果成功返回true
        requestor=org1_admin,
        peers=['peer0.org1.example.com',
               'peer1.org1.example.com'],
        cc_path='github.com/example_cc',
        # 注意链码路径，完整路径：/test/fixtures/chaincode/src/github.com/example_cc/example.cc.go，其中/src/github.com必须要有，否则报错
        cc_name='example_cc',
        cc_version='v1.0'
    ))
    return responses


def chaincode_instantiate():  # 实例化Chaincode，如果成功，响应应该为true
    args = ['a', '200', 'b', '300']  # 实例化的参数，与链码中init()函数对应
    policy = {  # 背书策略, see https://hyperledger-fabric.readthedocs.io/en/release-1.4/endorsement-policies.html
        'identities': [
            {'role': {'name': 'member', 'mspId': 'Org1MSP'}},
        ],
        'policy': {
            '1-of': [
                {'signed-by': 0},
            ]
        }
    }
    response = loop.run_until_complete(cli.chaincode_instantiate(
        requestor=org1_admin,
        channel_name='mychannel',  # 通道名称
        peers=['peer0.org1.example.com'],  # 指定在哪个peer上进行实例化，一个链码仅需在某个pee节点实例化一次即可
        args=args,  # 如果实例化链码传入的参数为空，则args = []
        cc_name='fabcar',  # 链码的名称
        cc_version='v1.0',  # 链码的版本
        cc_endorsement_policy=policy,  # 当前链码所使用的背书策略
        collections_config=None,  # optional, for private data policy
        transient_map=None,  # optional, for private data
        wait_for_event=True  # 确保链码实例化成功
    ))
    return response


def chaincode_invoke(args):  # 调用chaincode
    # args = ['2', '2', '2', '2', '2']
    # args = ['a', 'b', '50']
    response = loop.run_until_complete(cli.chaincode_invoke(  # 如果成功，返回为true
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com', 'peer1.org1.example.com'],
        args=args,
        cc_name='fabcar',
        fcn='createCar',  # 这里改为你链码中的函数名称
        transient_map=None,  # optional, for private data
        wait_for_event=True,
        # for being sure chaincode invocation has been commited in the ledger, default is on tx event
        #    cc_pattern='^invoked*' # if you want to wait for chaincode event and you have a `stub.SetEvent("invoked", value)` in your chaincode
    ))
    return response


def chaincode_query(args):
    # args = ["a"]
    response = loop.run_until_complete(cli.chaincode_query(  # 查询chaincode，如果成功，返回为true
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        args=args,
        cc_name='fabcar',
        fcn="query"
    ))
    return response


def chaincode_upgrade():  # 升级chaincode
    args = ['a', '200', 'b', '300']
    policy = {  # policy, see https://hyperledger-fabric.readthedocs.io/en/release-1.4/endorsement-policies.html
        'identities': [
            {'role': {'name': 'member', 'mspId': 'Org1MSP'}},
            {'role': {'name': 'admin', 'mspId': 'Org1MSP'}},
        ],
        'policy': {
            '1-of': [
                {'signed-by': 0}, {'signed-by': 1},
            ]
        }
    }
    response = loop.run_until_complete(cli.chaincode_upgrade(
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        args=args,
        cc_name='marbels_cc',
        cc_version='v1.0',
        cc_endorsement_policy=policy,  # optional, but recommended
        #    fcn='init',
        collections_config=None,  # optional, for private data policy
        transient_map=None,  # optional, for private data
        wait_for_event=True  # optional, for being sure chaincode is upgraded
    ))


def query_installed_chaincodes():  # 查询已安装的链码
    # 默认情况下，查询方法返回解码后的响应。如果你需要从区块链中获取原始响应，你可以添加decode=False参数。
    response = loop.run_until_complete(cli.query_installed_chaincodes(  # 查询Peer已安装的链码，确认链码已安装
        requestor=org1_admin,
        peers=['peer0.org1.example.com'],
        decode=True
    ))
    return response


def query_channels():
    response = loop.run_until_complete(cli.query_channels(  # 查询Peer加入的通道
        requestor=org1_admin,
        peers=['peer0.org1.example.com'],
        decode=True
    ))
    return response


def query_info():  # 根据区块Hash和交易id查询区块
    response = loop.run_until_complete(cli.query_info(  # 查询最新区块信息，返回区块高度、哈希值、上一区块哈希值
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        decode=True
    ))
    test_hash = response.currentBlockHash  # 将返回转化为Hash
    response = loop.run_until_complete(cli.query_block_by_hash(  # 通过区块Hash查询
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        block_hash=test_hash,
        decode=True
    ))
    tx_id = response.get('data').get('data')[0].get(
        'payload').get('header').get(
        'channel_header').get('tx_id')
    response = loop.run_until_complete(cli.query_block_by_txid(  # 通过交易id查询区块
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        tx_id=tx_id,
        decode=True
    ))
    return response


def query_block():  # 通过区块序号查询区块信息
    response = loop.run_until_complete(cli.query_block(
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        block_number='1',
        decode=True
    ))
    return response


def query_transaction(tx_id):  # 通过交易id查询交易
    response = loop.run_until_complete(cli.query_transaction(
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        tx_id=tx_id,  # tx_id same at 4.2
        decode=True
    ))
    return response


def query_instantiated_chaincodes():  # 查询实例化的链码
    response = loop.run_until_complete(cli.query_instantiated_chaincodes(
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        decode=True
    ))
    return response


def get_channel_config():
    response = loop.run_until_complete(cli.get_channel_config(  # 获取通道配置
        requestor=org1_admin,
        channel_name='mychannel',
        peers=['peer0.org1.example.com'],
        decode=True
    ))
    return response


def query_peers():
    response = loop.run_until_complete(cli.query_peers(
        requestor=org1_admin,
        peer='peer0.org1.example.com',
        channel='mychannel',
        local=False,  # True从本地通道发现获取配置,False从网络上的通道发现获取配置
        decode=True
    ))
    return response


def main():
    pass
    # 打印出网络中的organizations peer orderer CAs
    # print(cli.organizations, end='\n')
    # print(cli.peers, end='\n')
    # print(cli.orderers, end='\n')
    # print(cli.CAs, end='\n')

    # print(channel_create())
    # print(channel_join())
    # print(channel_update())
    # print(chaincode_install())
    # print(chaincode_instantiate())
    # print(chaincode_invoke())
    # print(chaincode_query())
    # print(chaincode_upgrade())
    # print(query_installed_chaincodes())
    # print(get_channel_config())
    # print(query_peers())

if __name__ == '__main__':
    main()